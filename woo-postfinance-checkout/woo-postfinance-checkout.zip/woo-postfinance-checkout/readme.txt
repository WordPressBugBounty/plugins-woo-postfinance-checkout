=== PostFinance Checkout ===
Contributors: PostFinance Ltd
Tags: payment, PostFinance Checkout, e-commerce, invoice, psp
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 3.4.7
License: Apache-2.0
License URI: http://www.apache.org/licenses/LICENSE-2.0

PostFinance Checkout

== Description ==

By PostFinance Ltd

With the PostFinance E-Payment Module, many payment methods for your online business are available in the Checkout back office tool. Depending on your needs and turnover volume, you can choose a standard commission rate or negotiate the price conditions simply and directly with the acceptance partners you require. This allows you to benefit from attractive prices and many useful features (such as configuration options for fraud management, the accounting feature, payment link for in-store payments).

Find out for yourself by testing our payment service provider solution free of charge in simulation mode. You can extend simulation mode after the 30-day trial period.

With our e-com bundle, you pay no set-up fee:
https://www.postfinance.ch/en/business/products/payment-collection/online-shop/e-com-bundle.html

== PostFinance Checkout contact and support ==

We are available to answer your questions and enquiries around the clock.

If you have technical problems, please contact our support team directly:
https://www.postfinance.ch/en/support/payments/transactions/postfinance-checkout-contact-and-support.html

== Platform availability information ==

For up-to-date information on maintenance work and disruptions to our Checkout platform, please visit our status page. Please check this page before contacting us. You can also subscribe to the latest disruption messages by e-mail.

== Go to Checkout status ==

Completely overhauled new version – Benefit now from the new, improved version of the plug-in, which resolves problems and uncertainties in the previous versions. The new version offers reliability and stability.

== Video ==

### PostFinance
https://www.youtube.com/watch?v=yX7iERUsRMA

### Plugin
https://www.youtube.com/watch?v=gzPfBybvpR0

== List of supported payment methods ==
The following payment methods can be offered with Checkout:

* PostFinance Pay
* Twint
* Visa
* Mastercard
* American Express
* Apple Pay
* Click to Pay
* Diners
* JCB
* Union Pay
* Purchase by invoice
* Fully automated payment in advance
* eBill
* Others on request

== List of plug-in features ==
Benefit from the following features when you use Checkout:

* Personalized e-mails and documents
* Simple accounting
* Fraud management
* Set-up service for QR module with eBill
* Always at your side: self-service support
* Personal support (free of charge)
* Creation of a payment QR code for occasional in-store payment collection
* Expansion with payment terminals to omnichannel for in-store payment collection

== How do I get a PostFinance account? ==
* Open an account for the product you require -> Product page
* Configure your account and choose your preferred payment methods
* Link the account to your WooCommerce shop
* Conclude the necessary contracts
* Get started

== Links to instructions/tutorials ==
[here](https://plugin-documentation.postfinance-checkout.ch/pfpayments/woocommerce/3.4.7/docs/en/documentation.html).

== About us ==
PostFinance is one of Switzerland’s leading financial institutions and is a reliable financial partner for around 2.5 million private and business customers. We offer our customers fresh solutions and smart innovations.
https://www.postfinance.ch/en/about-us.html

== FAQs ==
You can find the most important questions and answers on our website:
https://www.postfinance.ch/en/support/products/onlineshop-pos/questions-about-checkout-solutions.html

== Screenshots ==
1. Checkout desktop view
2. Checkout mobile view
3. Admin backend portal
4. Payment methods overview

== Tags ==
Twint; PostFinance; Switzerland; Checkout; Woo; WooCommerce

== External Services ==
This plugin includes an internal script to manage device verification within the WooCommerce store environment.

== Support ==
Support queries can be issued on the PostFinance Checkout support site.

== Privacy Policy ==
Enquiries about our privacy policy can be made on the PostFinance Checkout privacy policies site.

== Terms of use ==
Enquiries about our terms of use can be made on the PostFinance Checkout terms of use site.

== Features ==

Finance Checkout is a all-in-one payment solution from the PostFinance with a single contract. It supports PostFinance Card, PostFinance E-Finance, Visa, Mastercard and Twint.


== Installation ==
**Minimum Requirements**
* PHP version 7.4 or greater
* WordPress 4.7 up to 6.7
* WooCommerce 3.0.0 up to 9.8.5

**Automatic installation steps**
1. Install the plugin via **Plugins → Add New** and search for "PostFinance Checkout".
2. Activate the plugin in WordPress.
3. Set your credentials under **WooCommerce → Settings → PostFinance Checkout**.
4. Done — payment methods visible in checkout.

**Manual installation steps**
1. Upload files to `/wp-content/plugins/`.
2. Activate via ‘Plugins’.
3. Configure credentials under **WooCommerce → Settings → PostFinance Checkout**.
4. Payment methods appear in checkout.


== Frequently Asked Questions ==

= Where can I report issues? =

If you have an issue please check with PostFinance to resolve the issue. See [PostFinance Checkout](https://postfinance.ch/checkout).


== Changelog ==
Initial release with multilingual readme integration.

= 3.4.6 - July 7th 2026 =
- [Feature] Tested against WooCommerce 11.0.1
- [BugFix] Fixed race condition leading to failure to load pre selected payment fields
- [Tested Against] PHP 8.4.20
- [Tested Against] Wordpress 7
- [Tested Against] Woocommerce 11.0.1
- [Tested Against] PHP SDK 4.9.1
